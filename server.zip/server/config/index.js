module.exports = {
  JWT_SECRET: 'your-secret-key',  
  ZHIPU_API_KEY: 'eada087f63554e7085ef7a08222c1c4b.Konpt0AliOQ8eMCH'  // 添加智谱AI的API key
}; 