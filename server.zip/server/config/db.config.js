module.exports = {
  host: "localhost",
  user: "root",
  password: "123456",  // 确保这是你的正确密码
  database: "car_mall",
  port: 3306,
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
  charset: 'utf8mb4'
} 
